const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const TenantSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true }, // ✅ להוסיף אימייל לעסק
  passwordHash: { type: String, required: true }, // ✅ סיסמה מוצפנת

  settings: {
    currency: { type: String, default: 'ILS' },
    language: { type: String, default: 'he' },
    logo: String,
    address: String,
    phone: String
  },

  features: {
    type: Map,
    of: Boolean,
    default: {}
  }
}, { timestamps: true });

// ===== הצפנת סיסמה =====
TenantSchema.methods.setPassword = async function (plain) {
  const salt = await bcrypt.genSalt(12);
  this.passwordHash = await bcrypt.hash(plain, salt);
};

TenantSchema.methods.verifyPassword = async function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

module.exports = mongoose.model('Tenant', TenantSchema);
