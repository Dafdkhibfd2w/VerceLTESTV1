(() => {
  if (window.__DASHBOARD_INIT__) return;
  window.__DASHBOARD_INIT__ = true;

  let tenantData = null;
  let currentSection = "home";

  // ---------- THEME ----------
  function updateThemeIcon(theme) {
    const icon = document.getElementById("themeIcon");
    if (!icon) return;
    icon.className = theme === "dark" ? "fas fa-sun" : "fas fa-moon";
  }
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    updateThemeIcon(theme);
    window.showToast?.(theme === "dark" ? "מצב כהה הופעל" : "מצב בהיר הופעל", "info", 1200);
  }
  function initTheme() {
    const saved = localStorage.getItem("theme");
    const initial = (saved === "dark" || saved === "light") ? saved : "light";
    document.documentElement.setAttribute("data-theme", initial);
    updateThemeIcon(initial);
  }
  function toggleTheme() {
    const cur = document.documentElement.getAttribute("data-theme") || "light";
    applyTheme(cur === "dark" ? "light" : "dark");
  }
  function setTheme(theme) {
    if (theme !== "light" && theme !== "dark") return;
    applyTheme(theme);
  }

  // ---------- NAV ----------
  const sectionConfig = {
    home:      { title: "דף הבית",   subtitle: "לוח בקרה וניהול",   actionText: "חשבונית חדשה", actionIcon: "fa-plus" },
    invoices:  { title: "חשבוניות",  subtitle: "ניהול חשבוניות",    actionText: "חשבונית חדשה", actionIcon: "fa-plus" },
    customers: { title: "לקוחות",    subtitle: "ניהול לקוחות",       actionText: "הוסף לקוח",     actionIcon: "fa-user-plus" },
    suppliers: { title: "ספקים",     subtitle: "ניהול ספקים",        actionText: "הוסף ספק",      actionIcon: "fa-plus" },
    orders:    { title: "הזמנות",    subtitle: "ניהול הזמנות",       actionText: "הזמנה חדשה",    actionIcon: "fa-plus" },
    reports:   { title: "דוחות",     subtitle: "דוחות וסטטיסטיקות",  actionText: "ייצא דוח",      actionIcon: "fa-download" },
    settings:  { title: "הגדרות",    subtitle: "הגדרות מערכת",       actionText: "שמור שינויים",  actionIcon: "fa-save" }
  };
  const bottomNavItems = [
  { section: "home",      label: "בית",     icon: "fa-house" },
  { section: "invoices",  label: "חשבוניות", icon: "fa-file-invoice", feature: "invoices" },
  { section: "customers", label: "לקוחות",   icon: "fa-users",        feature: "customers" },
  { section: "suppliers", label: "ספקים",    icon: "fa-building",     feature: "suppliers" },
  { section: "orders",    label: "הזמנות",   icon: "fa-briefcase",    feature: "orders" },
  { section: "settings",  label: "הגדרות",   icon: "fa-gear" }
];
function renderBottomNav() {
  const el = document.getElementById("bottomNav");
  if (!el) return;
  const feats = tenantData?.features || {};

  el.innerHTML = bottomNavItems.map(item => {
    const disabled = item.feature ? !feats[item.feature] : false;
    return `
      <button class="nav-tab"
              data-section="${item.section}"
              ${disabled ? 'aria-disabled="true"' : ''}
              ${currentSection === item.section ? 'aria-current="page"' : ''}>
        <i class="fas ${item.icon}"></i>
        <span>${item.label}</span>
      </button>`;
  }).join("");

  // קליקים
  el.querySelectorAll(".nav-tab").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const s = btn.getAttribute("data-section");
      if (btn.getAttribute("aria-disabled") === "true") {
        window.showToast?.("המודול כבוי לעסק זה", "warning");
        return;
      }
      // שימוש בראוטר הקיים שלך
      if (location.hash !== `#${s}`) location.hash = `#${s}`;
      else navigateToSection(s);
    });
  });
}

function applyBottomNavGates() {
  const el = document.getElementById("bottomNav");
  if (!el) return;
  const feats = tenantData?.features || {};
  el.querySelectorAll(".nav-tab").forEach(btn => {
    const sec = btn.getAttribute("data-section");
    const item = bottomNavItems.find(i => i.section === sec);
    const need = item?.feature;
    const on = need ? !!feats[need] : true;
    btn.classList.toggle("disabled", !on);
    btn.setAttribute("aria-disabled", String(!on));
  });
}
function setActiveNav(sectionName) {
  // תפריטים קיימים (אם יש)
  document.querySelectorAll(".nav-item").forEach(item => {
    item.classList.toggle("active", item.getAttribute("data-section") === sectionName);
  });
  // BottomNav
  document.querySelectorAll("#bottomNav .nav-tab").forEach(btn => {
    const isActive = btn.getAttribute("data-section") === sectionName;
    btn.classList.toggle("active", isActive);
    if (isActive) btn.setAttribute("aria-current", "page");
    else btn.removeAttribute("aria-current");
  });
}
  function updateHeaderForSection(sectionName) {
    const cfg = sectionConfig[sectionName] || sectionConfig.home;
    const titleEl = document.getElementById("sectionTitle");
    const subEl = document.getElementById("sectionSubtitle");
    const actionBtn = document.getElementById("primaryActionBtn");
    const actionText = document.getElementById("primaryActionText");

    if (titleEl) titleEl.textContent = cfg.title;
    if (subEl) subEl.textContent = cfg.subtitle;
    if (actionText) actionText.textContent = cfg.actionText;
    if (actionBtn) {
      const i = actionBtn.querySelector("i");
      if (i) i.className = `fas ${cfg.actionIcon}`;
      actionBtn.dataset.section = sectionName;
    }
  }



function navigateToSection(sectionName) {
  const el = document.getElementById(`section-${sectionName}`);

  // 🛑 אם הסקשן כבוי – נחזיר לדף הבית
  if (el && el.matches('[data-feature].disabled')) {
    window.showToast?.("אין לך גישה לעמוד זה", "warning");
    location.hash = "#home";
    return;
  }

  document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
  if (el) el.classList.add("active");
  setActiveNav(sectionName);
  updateHeaderForSection(sectionName);
  currentSection = sectionName;
}

  function handleHashRoute() {
    const raw = (location.hash || "#home").slice(1);
    const section = sectionConfig[raw] ? raw : "home";
    navigateToSection(section);
  }

  function bindNavEvents() {
    document.querySelectorAll(".nav-item").forEach(item => {
      item.addEventListener("click", (e) => {
        e.preventDefault();
        const s = item.getAttribute("data-section") || "home";
        if (location.hash !== `#${s}`) location.hash = `#${s}`;
        else navigateToSection(s);
      });
    });
    window.addEventListener("hashchange", handleHashRoute);
  }

  // ---------- USER / TENANT ----------
  async function loadCurrentUser() {
    try {
      const res = await fetch("/me", { credentials: "include" });
      const data = await res.json();
      if (data?.ok && data.user) {
        setUserUI(data.user);
        return data.user;
      }
    } catch {}
    setUserUI({ username: "אורח", role: "user" });
  }

  function setUserUI(user) {
    const nameEl = document.getElementById("currentUserName");
    const roleEl = document.getElementById("currentUserRole");
    if (nameEl) nameEl.textContent = user.username || user.name || "משתמש";
    if (roleEl) roleEl.textContent = user.role || "משתמש";
  }

  async function loadTenant() {
    try {
      const res = await fetch("/api/tenant/info", { credentials: "include" });
      const data = await res.json();
      if (data?.ok) {
        setUserUI({
          username: data.currentUser?.name,
          role: data.currentUser?.role
        });
        tenantData = normalizeTenant(data);
        renderTenant();
        applyFeatureGates();
        return;
      }
    } catch (e) { console.error("loadTenant error", e); }

    // fallback
    tenantData = {
      name: "העסק שלי",
      createdAt: new Date().toISOString(),
      ownerName: "—",
      ownerEmail: "—",
      address: "",
      phone: "",
      team: [],
      features: {}
    };
    renderTenant();
    applyFeatureGates();
  }

  function normalizeTenant(payload) {
    const t = payload?.tenant || {};
    const owner = payload?.owner || null;
    const team = Array.isArray(payload?.teamMembers) ? payload.teamMembers : [];
    const feats = t.features || {};

    return {
      id: t.id || t._id || null,
      name: t.name || "העסק שלי",
      createdAt: t.createdAt || new Date().toISOString(),
      settings: t.settings || {},
      ownerName: owner?.name || "—",
      ownerEmail: owner?.email || "—",
      address: t.settings?.address || "",
      phone: t.settings?.phone || "",
      team: team.map(m => ({ name: m.name, role: m.role || "staff", email: m.email })),
      features: feats
    };
  }

  function renderTenant() {
    if (!tenantData) return;
    const nameMain = document.getElementById("tenantName");
    const nameSidebar = document.getElementById("tenantNameSidebar");
    const createdEl = document.getElementById("tenantCreated");
    const ownerNameEl = document.getElementById("ownerName");
    const ownerEmailEl = document.getElementById("ownerEmail");

    if (nameMain) nameMain.textContent = tenantData.name;
    if (nameSidebar) nameSidebar.textContent = tenantData.name;
    if (createdEl) createdEl.textContent = formatDate(tenantData.createdAt);
    if (ownerNameEl) ownerNameEl.textContent = tenantData.ownerName || "—";
    if (ownerEmailEl) ownerEmailEl.textContent = tenantData.ownerEmail || "—";

    renderTeamList(tenantData.team);
    wrap.querySelectorAll('.member__copy').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const email = btn.closest('.member__email')?.querySelector('.member__emailText')?.textContent?.trim();
    if (email) { navigator.clipboard?.writeText(email); showToast?.('האימייל הועתק', 'success'); }
  });
});

// דאבל-קליק על שורת האימייל -> מציג מלא/חוזר לקיצור
wrap.querySelectorAll('.member__email').forEach(row=>{
  row.addEventListener('dblclick', ()=>{
    row.classList.toggle('is-expanded');
    const t = row.querySelector('.member__emailText');
    if (!t) return;
    if (row.classList.contains('is-expanded')) {
      t.style.whiteSpace = 'normal'; t.style.wordBreak = 'break-all';
    } else {
      t.style.whiteSpace = 'nowrap'; t.style.wordBreak = 'normal';
    }
  });
});
    const teamCount = document.getElementById("teamCount");
    if (teamCount) teamCount.textContent = String(tenantData.team.length || 0);

    const sName  = document.getElementById("settingsTenantName");
    const sAddr  = document.getElementById("settingsAddress");
    const sPhone = document.getElementById("settingsPhone");
    if (sName  && document.activeElement !== sName)  sName.value  = tenantData.name || "";
    if (sAddr  && document.activeElement !== sAddr)  sAddr.value  = tenantData.address || "";
    if (sPhone && document.activeElement !== sPhone) sPhone.value = tenantData.phone || "";
  }
function initials(name='') {
  const parts = String(name).trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0,2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

function roleClass(role) {
  switch ((role||'').toLowerCase()) {
    case 'owner': return 'role-owner';
    case 'manager': return 'role-manager';
    default: return 'role-employee';
  }
}
function memberItemTemplate(m) {
  const role = (m.role || 'employee').toLowerCase();
  const roleLabel = role === 'owner' ? 'Owner' : role === 'manager' ? 'Manager' : 'Employee';

  return `
    <div class="member" data-id="${m.id || ''}">
      <div class="avatar">${initials(m.name || m.email || '?')}</div>

      <div class="info">
        <div class="name"><bdi>${escapeHtml(m.name || m.email || '—')}</bdi></div>
        ${m.email ? `<div class="email"><i class="fas fa-envelope"></i> <bdi>${escapeHtml(m.email)}</bdi></div>` : ''}
      </div>

      <span class="role ${role}">${roleLabel}</span>

      <div class="actions">
        <button class="icon-btn primary" title="ערוך" data-action="edit"><i class="fas fa-pen"></i></button>
        <button class="icon-btn danger"  title="מחק" data-action="delete"><i class="fas fa-trash"></i></button>
      </div>
    </div>`;
}

// === Add Member Modal logic ===
function openAddMemberModal(){
  const m = document.getElementById('addMemberModal');
  if (!m) return;
  // איפוס טופס
  document.getElementById('addMemberForm').reset();
  m.classList.remove('hidden');
  document.body.classList.add('modal-open');
  // פוקוס לשם
  setTimeout(()=> document.getElementById('am_name')?.focus(), 50);
}

function closeAddMemberModal(){
  const m = document.getElementById('addMemberModal');
  if (!m) return;
  m.classList.add('hidden');
  document.body.classList.remove('modal-open');
}

async function createMember(){
  const btn = document.getElementById('am_submit');
  const name = (document.getElementById('am_name')?.value || '').trim();
  const email = (document.getElementById('am_email')?.value || '').trim();
  const password = (document.getElementById('am_password')?.value || '').trim();
  const role = (document.getElementById('am_role')?.value || 'employee');
  const sendInvite = !!document.getElementById('am_sendInvite')?.checked;

  // ולידציות מהירות בצד לקוח
  if (!name)      { showToast?.('נא להזין שם', 'warning'); return; }
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) { showToast?.('אימייל לא תקין', 'warning'); return; }
  if (!password || password.length < 8) { showToast?.('הסיסמה קצרה מדי (מינ׳ 8)', 'warning'); return; }

  btn.disabled = true;

  try {
    const csrf = await getCsrfToken();
    const res = await fetch('/api/team/members', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf },
      body: JSON.stringify({ name, email, password, role, sendInvite })
    });
    const data = await res.json().catch(()=> ({}));
    if (!res.ok || data?.ok === false) throw new Error(data?.message || `HTTP ${res.status}`);

    // מוסיפים לרשימה באופן מיידי (optimistic)
    const newMember = {
      id: data?.member?.id || data?.member?._id || null,
      name, email, role
    };
    if (Array.isArray(tenantData?.team)) tenantData.team.push(newMember);
    renderTeamList(tenantData?.team || []);
    closeAddMemberModal();
    showToast?.('המשתמש נוצר בהצלחה', 'success');
  } catch (e){
    showToast?.(e?.message || 'שגיאה ביצירת משתמש', 'error');
  } finally {
    btn.disabled = false;
  }
}

// חיבורים
document.getElementById('btnAddMember')?.addEventListener('click', openAddMemberModal);
document.querySelector('#addMemberModal .modal-close')?.addEventListener('click', closeAddMemberModal);
document.querySelector('#addMemberModal .modal-cancel')?.addEventListener('click', (e)=>{ e.preventDefault(); closeAddMemberModal(); });
document.getElementById('am_submit')?.addEventListener('click', (e)=>{ e.preventDefault(); createMember(); });

async function renderTeamList(team=[]) {
  const wrap = document.getElementById('teamList');
  if (!wrap) return;
  if (!team.length) {
    wrap.innerHTML = `<div class="empty"><i class="fas fa-users-slash"></i> עדיין אין משתמשים</div>`;
    return;
  }
  wrap.innerHTML = team.map(memberItemTemplate).join('');

wrap.querySelectorAll('.tm-copy').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const email = btn.closest('.tm-email')?.querySelector('.tm-emailText')?.textContent?.trim();
    if (email) { navigator.clipboard?.writeText(email); showToast?.('האימייל הועתק', 'success'); }
  });
});
}

async function confirmDeleteMember(id, rowEl){
  if (!confirm('למחוק משתמש זה?')) return;
  try {
    const csrf = await getCsrfToken();
    const res = await fetch(`/api/users/${id}`, { method:'DELETE', credentials:'include', headers:{'x-csrf-token':csrf} });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    rowEl?.remove();
    showToast?.('נמחק בהצלחה', 'success');
  } catch(e){
    showToast?.(e.message || 'שגיאה במחיקה', 'error');
  }
}

function openEditMemberSheet(id){
  // כאן אפשר לפתוח sheet/מודאל עריכה – לפי התשתית שכבר בנית לפיצ'רים
  showToast?.('עריכה בקרוב…', 'info');
}
  // ---------- FEATURE GATES ----------
  function applyFeatureGates() {
    const feats = tenantData?.features || {};
    document.querySelectorAll('[data-feature]').forEach(el => {
      const key = el.getAttribute('data-feature');
      const on = !!feats[key];
      el.classList.toggle('disabled', !on);
      el.setAttribute('aria-disabled', String(!on));
    });
    // אם נמצאים בסקשן כבוי – חזרה הביתה
    const cur = (location.hash || '#home').slice(1);
    const el = document.getElementById(`section-${cur}`);
    if (el && el.matches('[data-feature].disabled')) location.hash = '#home';
    applyBottomNavGates();
  }

  // ---------- MODAL ----------
  function openEditModal() {
    const el = document.getElementById("editModal");
    if (!el) return;
    document.getElementById("editTenantName").value = tenantData?.name || "";
    document.getElementById("editTenantAddress").value = tenantData?.address || "";
    document.getElementById("editTenantPhone").value = tenantData?.phone || "";
    el.classList.remove("hidden");
    document.body.classList.add("modal-open");
  }
  function closeEditModal() {
    const el = document.getElementById("editModal");
    if (!el) return;
    el.classList.add("hidden");
    document.body.classList.remove("modal-open");
  }

  // ---------- ACTIONS ----------
  function handlePrimaryAction(section) {
    switch (section) {
      case "home":
      case "invoices":  window.showToast?.("פתיחת חשבונית חדשה", "info"); break;
      case "customers": window.showToast?.("הוספת לקוח", "info"); break;
      case "suppliers": window.showToast?.("הוספת ספק", "info"); break;
      case "orders":    window.showToast?.("יצירת הזמנה חדשה", "info"); break;
      case "reports":   window.showToast?.("ייצוא דוח...", "success"); break;
      case "settings":  window.showToast?.("נשמרו שינויים", "success"); break;
      default:          window.showToast?.("פעולה ראשית", "info");
    }
  }

  async function logout() {
    try { await fetch("/logout", { method: "GET", credentials: "include" }); } catch {}
    location.href = "/login";
  }

  // ---------- HELPERS ----------
  function formatDate(dateStr) {
    try { return new Date(dateStr).toLocaleDateString("he-IL", { year: "numeric", month: "2-digit", day: "2-digit" }); }
    catch { return "—"; }
  }
  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  // ---------- Loader (CSP-safe) ----------
  
  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  const nextFrame = () => new Promise(r => requestAnimationFrame(() => r()));
  async function waitForImages(scope = document) {
    const imgs = [...scope.querySelectorAll('img')].filter(img => !img.complete);
    if (!imgs.length) return;
    await Promise.all(imgs.map(img => new Promise(res => {
      img.addEventListener('load', res, { once: true });
      img.addEventListener('error', res, { once: true });
    })));
  }
  async function flushUI(scope = document) {
    const fontsReady = (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
    await Promise.all([fontsReady, waitForImages(scope)]);
    await nextFrame(); await nextFrame();
  }
  async function withLoader(run, { text="טוען...", subtext="מביא נתונים", scopeSelector=".main-content", minShow=300 } = {}) {
    showLoader(text, subtext);
    const t0 = performance.now();
    try {
      const result = await run();
      const scope = document.querySelector(scopeSelector) || document.body;
      await flushUI(scope);
      const elapsed = performance.now() - t0;
      if (elapsed < minShow) await delay(minShow - elapsed);
      return result;
    } finally { hideLoader(); }
  }

  // ---------- CSRF / PUT helpers ----------
  async function getCsrfToken() {
    const r = await fetch("/csrf-token", { credentials: "include" });
    const j = await r.json().catch(() => ({}));
    if (!j?.csrfToken) throw new Error("CSRF token missing");
    return j.csrfToken;
  }
  async function putJSON(url, body) {
    const csrf = await getCsrfToken();
    const res = await fetch(url, {
      method: "PUT",
      credentials: "include",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf },
      body: JSON.stringify(body)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data?.ok === false) {
      const msg = data?.message || `HTTP ${res.status}`;
      const err = new Error(msg); err.status = res.status; err.data = data;
      throw err;
    }
    return data;
  }

  // ---------- Save settings ----------
  async function saveBusinessSettings() {
    const name  = (document.getElementById("settingsTenantName")?.value || "").trim();
    const addr  = (document.getElementById("settingsAddress")?.value || "").trim();
    const phone = (document.getElementById("settingsPhone")?.value || "").trim();

    await withLoader(async () => {
      const resp = await putJSON("/api/tenant/update", { name, settings: { address: addr, phone } });
      tenantData.name    = resp?.tenant?.name || name;
      tenantData.address = resp?.tenant?.settings?.address || addr;
      tenantData.phone   = resp?.tenant?.settings?.phone   || phone;
      renderTenant();
    }, { text: "שומר הגדרות...", subtext: "מעדכן את פרטי העסק בשרת" })
    .then(() => window.showToast?.("העסק עודכן בהצלחה", "success"))
    .catch(err => {
      if (err?.status === 403) window.showToast?.("אין לך הרשאה לעדכן את העסק", "error");
      else window.showToast?.(err?.message || "שגיאה בעדכון העסק", "error");
    });
  }

  async function savePersonalSettings() {
    const newName = (document.getElementById("settingsUserName")?.value || "").trim();
    if (!newName) { window.showToast?.("יש להזין שם מלא", "warning"); return; }

    await withLoader(async () => {
      const csrf = await getCsrfToken();
      const res = await fetch("/api/user/update", {
        method: "PUT",
        credentials: "include",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrf },
        body: JSON.stringify({ name: newName })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data?.ok === false) throw new Error(data?.message || `HTTP ${res.status}`);
      setUserUI({ username: data.user?.name || newName, role: document.getElementById("currentUserRole")?.textContent || "משתמש" });
      return data;
    }, { text: "שומר פרטים אישיים...", subtext: "מעדכן את הפרופיל שלך" })
    .then(() => window.showToast?.("הפרופיל עודכן בהצלחה", "success"))
    .catch(err => window.showToast?.(err?.message || "שגיאה בעדכון הפרופיל", "error"));
  }

  async function saveTenantChanges() {
    const name  = (document.getElementById("editTenantName")?.value || "").trim();
    const addr  = (document.getElementById("editTenantAddress")?.value || "").trim();
    const phone = (document.getElementById("editTenantPhone")?.value || "").trim();

    await withLoader(async () => {
      const resp = await putJSON("/api/tenant/update", { name, settings: { address: addr, phone } });
      tenantData.name    = resp?.tenant?.name || name;
      tenantData.address = resp?.tenant?.settings?.address || addr;
      tenantData.phone   = resp?.tenant?.settings?.phone   || phone;
      renderTenant();
    }, { text: "שומר שינויים...", subtext: "מעדכן את פרטי העסק" })
    .then(() => { closeEditModal(); window.showToast?.("פרטי העסק נשמרו", "success"); })
    .catch(err => window.showToast?.(err?.message || "שגיאה בעדכון", "error"));
  }

  // ---------- INIT ----------
  document.addEventListener("DOMContentLoaded", async () => {
    initTheme();

    await withLoader(async () => {
      // guard
      const me = await fetch("/me", { credentials: "include" }).then(r => r.json());
      if (!me?.ok || !me.user) { location.href = "/login"; return; }
      setUserUI(me.user);
      const uNameEl  = document.getElementById("settingsUserName");
      const uMailEl  = document.getElementById("settingsEmail");
      if (uNameEl && !uNameEl.value) uNameEl.value = me.user.name || "";
      if (uMailEl && !uMailEl.value) uMailEl.value = me.user.email || "";

      // tenant
      const r = await fetch("/api/tenant/info", { credentials: "include" });
      if (!r.ok) { location.href = "/login"; return; }
      const data = await r.json();
      if (!data?.ok || !data?.tenant) { location.href = "/login"; return; }

      tenantData = normalizeTenant(data);
      renderTenant();
      applyFeatureGates();
renderBottomNav();
applyBottomNavGates();
      // nav + actions
      bindNavEvents();
      handleHashRoute();

      const primaryActionBtn = document.getElementById("primaryActionBtn");
      if (primaryActionBtn) {
        primaryActionBtn.addEventListener("click", () => {
          const s = primaryActionBtn.dataset.section || currentSection;
          handlePrimaryAction(s);
        });
      }
      document.querySelector(".theme-toggle")?.addEventListener("click", toggleTheme);
      const themeOpts = document.querySelectorAll(".theme-options .theme-option");
      if (themeOpts[0]) themeOpts[0].addEventListener("click", () => setTheme("light"));
      if (themeOpts[1]) themeOpts[1].addEventListener("click", () => setTheme("dark"));
      document.querySelector(".btn-logout")?.addEventListener("click", logout);

      document.getElementById("editTenantBtn")?.addEventListener("click", openEditModal);
      document.querySelector("#editModal .modal-close")?.addEventListener("click", closeEditModal);
      document.querySelector("#editModal .modal-footer .btn.btn-primary")?.addEventListener("click", saveTenantChanges);

      // settings save buttons
      document.querySelector("#section-settings .card:nth-of-type(1) .btn.btn-primary")?.addEventListener("click", saveBusinessSettings);
      document.querySelector("#section-settings .card:nth-of-type(2) .btn.btn-primary")?.addEventListener("click", savePersonalSettings);
    }, {
      text: "טוען לוח בקרה...",
      subtext: "מביא נתונים מהשרת",
      scopeSelector: ".main-content",
      minShow: 300
    });
  });
})();
