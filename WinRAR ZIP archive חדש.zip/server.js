// server.js (auth-only)
require("dotenv").config();

const express       = require("express");
const path          = require("path");
const cookieParser  = require("cookie-parser");
const bodyParser    = require("body-parser");
const helmet        = require("helmet");
const rateLimit     = require("express-rate-limit");
const hpp           = require("hpp");
const cors          = require("cors");
const csrf          = require("csurf");
const jwt           = require("jsonwebtoken");

const { connectMongoose } = require("./db"); // מחבר ל-MongoDB (מומלץ שמחזיר חיבור יחיד)
const User = require("./models/user");       // מודל משתמש קיים אצלך

// ===== App & Config =====
const app   = express();
const PORT  = process.env.PORT || 8080;
const SECRET = process.env.JWT_SECRET;
const isProd = process.env.NODE_ENV === "production";

// ===== Middlewares (base) =====
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// סטטי (ל־CSS/JS/תמונות)
app.use(express.static("public", {
  maxAge: 0,
  etag: false,
  lastModified: false
}));
// קטלוג פיצ'רים – מקור האמת לשמות/אייקונים/ברירת מחדל
const FEATURE_CATALOG = {
  invoices:  { label: "חשבוניות",  icon: "fa-file-invoice", default: false },
  customers: { label: "לקוחות",    icon: "fa-users",         default: false },
  suppliers: { label: "ספקים",     icon: "fa-building",      default: false },
  orders:    { label: "הזמנות",    icon: "fa-box",           default: false },
  reports:   { label: "דוחות",     icon: "fa-chart-line",    default: false }
};

// אבטחה
app.use(helmet({
  crossOriginResourcePolicy: { policy: "same-site" },
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: [
        "'self'",
        "'unsafe-inline'",     // הורד בפרודקשן אם אפשר
        "'unsafe-eval'",       // הורד בפרודקשן אם אפשר
        "https://www.gstatic.com",
        "https://www.googleapis.com",
        "https://www.google.com",
        "https://apis.google.com",
        "https://www.recaptcha.net",
        "https://cdn.jsdelivr.net",
        "https://vercel.live", "https://*.vercel.live",
      ],
      connectSrc: [
        "'self'",
        "https://www.gstatic.com",
        "https://www.googleapis.com",
        "https://identitytoolkit.googleapis.com",
        "https://securetoken.googleapis.com",
        "https://www.recaptcha.net",
        "https://cdn.jsdelivr.net",
        "https://vercel.live", "https://*.vercel.live",
        "wss://vercel.live",   "wss://*.vercel.live",
      ],
      frameSrc: [
        "'self'",
        "https://www.google.com",
        "https://www.gstatic.com",
        "https://www.recaptcha.net",
        "https://vercel.live", "https://*.vercel.live",
      ],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
      fontSrc:  ["'self'", "data:", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
    }
  }
}));

app.use(cors({
  origin: ["http://localhost:3000","https://closemanages.vercel.app"],
  credentials: true
}));

app.use(hpp());

// אין קאשינג לקבצי HTML/CSS/JS (לנוחות פיתוח)
app.use((req, res, next) => {
    const tag = `${req.method} ${req.url}`;
  console.time(tag);
  res.on('finish', () => console.timeEnd(tag));
  if (/\.(html|css|js)$/.test(req.url)) {
    res.setHeader("Cache-Control", "no-store");
  }
  next();
});

// ===== Mongo Connect (חד-פעמי) =====
(async () => {
  try {
    await connectMongoose();
    console.log("✅ Mongo connected");
  } catch (e) {
    console.error("❌ Mongo connect failed:", e);
  }
})();

// ===== Utils =====
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false
});
app.use(["/login","/register","/auth/request-email-code","/auth/verify-email-code"], authLimiter);

const nodemailer = require("nodemailer");
const emailOtpStore = Object.create(null);

const mailer = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  },
  tls: { rejectUnauthorized: false },
  debug: true,
  logger: true
});

function genCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
function isEmail(str) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(str || "").toLowerCase());
}

// ===== CSRF =====
const csrfProtection = csrf({
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd
  }
});
app.use(csrfProtection);
app.get("/csrf-token", (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});
const authenticateUser = async (req, res, next) => {
  try {
    const token = req.cookies.token;
    if (!token) {
      return res.redirect('/login.html');
    }

    const decoded = jwt.verify(token, SECRET);
    const user = await User.findById(decoded.id)
      .populate('TenantID')  // טוען את פרטי הטנאנט
      .lean();
    
    if (!user) {
      return res.redirect('/login.html');
    }

    req.user = user;  // שומרים את המשתמש ב-request
    next();
  } catch (err) {
    console.error('Auth middleware error:', err);
    res.redirect('/login.html');
  }
};
function requireAuthPage(req, res, next) {
  try {
    const token = req.cookies?.token;
    if (!token) return res.redirect("/login");
    jwt.verify(token, SECRET);  // אם לא תקין → נקפוץ ל-catch
    return next();
  } catch {
    return res.redirect("/login");
  }
}


// authz.js
function isPlatformAdmin(user) {
  const list = (process.env.PLATFORM_ADMIN_EMAILS || "")
    .split(",")
    .map(s => s.trim().toLowerCase())
    .filter(Boolean);

  const byEnv = list.includes(String(user.email || "").toLowerCase());
  const byDb  = user.platformRole === "admin";
  return byEnv || byDb;
}

// תומך גם ב-CSV וגם ב-JSON array, מסיר רווחים וממיר ל-lowercase
function parseAdminList(val) {
  if (!val) return [];
  try {
    const arr = JSON.parse(val);
    if (Array.isArray(arr)) {
      return arr.map(s => String(s).trim().toLowerCase()).filter(Boolean);
    }
  } catch {}
  return String(val)
    .split(/[,;|\s]+/)
    .map(s => s.replace(/^[\[\]'"\s]+|[\[\]'"\s]+$/g, '').trim().toLowerCase())
    .filter(Boolean);
}

// נשתמש בשם שהגדרת + שם גיבוי אם השתמשת בו קודם
const PLATFORM_ADMINS = (process.env.PLATFORM_ADMIN_EMAILS || "")
  .split(",").map(s => s.trim().toLowerCase()).filter(Boolean);

function requirePlatformAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ ok:false, message:"Unauthorized" });
  const email = (req.user.email || "").toLowerCase();
  const isAdmin = req.user.platformRole === "admin" || PLATFORM_ADMINS.includes(email);
  if (!isAdmin) return res.status(403).json({ ok:false, message:"Forbidden" });
  next();
}

// ===== Views (Auth pages only) =====
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "register.html"));
});

app.get('/admin', authenticateUser, requirePlatformAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'admin.html'));
});

app.get("/", requireAuthPage, (req, res) => {
  res.sendFile(path.join(__dirname, "views", "dashboard.html"));
});
const Tenant = require('./models/Tenant');
app.get('/api/admin/features-catalog',   authenticateUser, requirePlatformAdmin, (req, res) => {
  res.json({ ok: true, features: FEATURE_CATALOG });
});

app.get("/api/admin/tenants",
  authenticateUser,
  requirePlatformAdmin,
  async (req, res) => {
    const tenants = await Tenant.find({})
      .select("name createdAt owner settings features")
      .populate({ path: "owner", select: "name email" })
      .lean();

    res.json({
      ok: true,
      tenants: tenants.map(t => ({
        id: String(t._id),
        name: t.name,
        createdAt: t.createdAt,
        owner: t.owner ? { name: t.owner.name, email: t.owner.email } : null,
        settings: t.settings || {},
        features: t.features || {}
      }))
    });
  }
);


// server.js
// עדכון פיצ'רים ע"י אדמין פלטפורמה
app.put("/api/admin/tenants/:id/features",
  authenticateUser, requirePlatformAdmin, async (req, res) => {
    const { id } = req.params;
    const { key, value, ...bulk } = req.body || {};

    const tenant = await Tenant.findById(id);
    if (!tenant) return res.status(404).json({ ok:false, message:"עסק לא נמצא" });

    // ודא שיש features
    if (!tenant.features) {
      tenant.features = new Map();
    }

    // אם זה לא Map, המר ל-Map (תאימות לעבר)
    if (!(tenant.features instanceof Map) && typeof tenant.features === 'object') {
      tenant.features = new Map(Object.entries(tenant.features));
    }

    let changed = false;

    if (typeof key === "string") {
      tenant.features.set(key, !!value);
      changed = true;
    } else {
      for (const [k, v] of Object.entries(bulk)) {
        tenant.features.set(k, !!v);
        changed = true;
      }
    }

    if (changed) tenant.markModified('features');

    await tenant.save();

    // החזר תמיד אובייקט פשוט לפרונט
    const plain = Object.fromEntries(tenant.features instanceof Map
      ? tenant.features
      : Object.entries(tenant.features || {}));

    res.json({ ok:true, features: plain });
  }
);
// POST /api/team/members
app.post('/api/team/members', authenticateUser, async (req,res)=>{
  try{
    let { name, email, password, role='employee', sendInvite=true } = req.body || {};
    if (!name || !email || !password) return res.status(400).json({ ok:false, message:'Missing fields' });
    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ ok:false, message:'Invalid email' });
    if (password.length < 8) return res.status(400).json({ ok:false, message:'Password too short' });

    // נירמול תפקיד
    role = String(role || 'employee').toLowerCase();
    if (!['employee','manager'].includes(role)) role = 'employee';

    const tenantId   = req.user.tenantId;
    const tenantName = req.user.tenantName || 'העסק שלך';
    const baseUrl    = process.env.BASE_URL || 'https://your-app-url';

    // כפילות לפי טננט
    const exists = await Users.findOne({ email, tenantId });
    if (exists) return res.status(409).json({ ok:false, message:'Email already exists' });

    // יצירה
    const hash = await bcrypt.hash(password, 12);
    const user = await Users.create({
      tenantId,
      name,
      email,
      passwordHash: hash,
      role,
      status: 'active',
      mustChangePassword: true, // יחויב להחליף סיסמה בכניסה ראשונה
      createdBy: req.user.id
    });

    // שליחת מייל הזמנה עם פרטי ההתחברות
    if (sendInvite) {
      // שים לב: אין console.log של הסיסמה – לא לחשוף לוגים
      const subject = `קבלת גישה ל-${tenantName} במערכת New Deli`;
      const loginUrl = `${baseUrl}/login`;

      // טקסט (fallback לכל לקוח דואר)
      const text = `שלום ${name},

נוצר עבורך משתמש במערכת New Deli עבור העסק: ${tenantName}.

פרטי ההתחברות שלך:
אימייל: ${email}
סיסמה: ${password}

כניסה למערכת: ${loginUrl}

מומלץ מאוד לשנות סיסמה לאחר ההתחברות הראשונה.
בהצלחה!`;

      // HTML (נראה יותר יפה בלקוחי דוא"ל מודרניים)
      const html = `
        <div style="font-family:Heebo,Arial,sans-serif;line-height:1.6;color:#222">
          <h2 style="margin:0 0 12px">ברוך הבא ל-New Deli</h2>
          <p>נוצר עבורך משתמש עבור העסק: <b>${escapeHtml(tenantName)}</b>.</p>
          <div style="background:#f6f7f9;border:1px solid #e3e6ea;border-radius:10px;padding:12px 14px;margin:12px 0">
            <div><b>אימייל:</b> <span dir="ltr">${escapeHtml(email)}</span></div>
            <div><b>סיסמה:</b> <span dir="ltr">${escapeHtml(password)}</span></div>
          </div>
          <p>
            <a href="${loginUrl}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:10px 16px;border-radius:8px">
              התחברות למערכת
            </a>
          </p>
          <p style="color:#555;font-size:14px">מומלץ לשנות סיסמה לאחר ההתחברות הראשונה.</p>
        </div>
      `;

      try {
        await mailer.sendMail({
          from: `"New Deli" <${process.env.SMTP_USER}>`,
          to: email,
          subject,
          text,
          html
        });
      } catch (e) {
        // לא מפיל את הבקשה – רק מודיע לקליינט
        console.error('invite email failed:', e.message);
      }
    }

    res.json({ ok:true, member: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e){
    console.error(e);
    res.status(500).json({ ok:false, message:'Server error' });
  }
});


// 🔹 שליחת קוד למייל - מעדכנים לשמור את tenantName
app.post("/auth/request-email-code", async (req, res) => {
  try {
    const { name, email, tenantName, tenantPhone } = req.body || {};  // 🆕 קוראים tenantName
const cleanName        = String(name || "").trim();
const cleanEmail       = String(email || "").trim().toLowerCase();
const cleanTenantName  = String(tenantName || "").trim();
const cleanTenantPhone = String(tenantPhone || "").trim();

    // ✅ בדיקת תקינות
if (!cleanName || !isEmail(cleanEmail) || !cleanTenantName || !cleanTenantPhone) {
  return res.status(400).json({
    ok: false,
    message: "יש למלא שם, אימייל, שם עסק ומספר טלפון"
  });
}

    const code = genCode();
    
    // 🆕 שומרים גם את tenantName ב-store הזמני
emailOtpStore[cleanEmail] = {
  code,
  name: cleanName,
  tenantPhone: cleanTenantPhone,
  tenantName: cleanTenantName,
  expires: Date.now() + 5 * 60 * 1000
};

    await mailer.sendMail({
      from: `"New Deli" <${process.env.SMTP_USER}>`,
      to: cleanEmail,
      subject: "קוד התחברות",
      text: `שלום ${cleanName}, הקוד שלך הוא: ${code} (תקף ל-5 דקות).`
    });

    res.json({ ok: true, message: "נשלח קוד לאימייל" });
  } catch (err) {
    console.error("request-email-code error:", err);
    res.status(500).json({ ok: false, message: "שגיאה בשליחת הקוד" });
  }
});
const requireTenantFeature = (feature) => async (req, res, next) => {
  const t = await Tenant.findById(req.user.TenantID).select('features');
  if (!t?.features?.[feature]) {
    return res.status(403).json({ ok:false, message:'הפיצ׳ר לא פעיל לעסק זה' });
  }
  next();
};

// דוגמה להגנה:
app.get('/api/invoices', authenticateUser, requireTenantFeature('invoices'),
  async (req, res) => { /* ... */ }
);
// 🔹 אימות קוד - יצירת משתמש עם Tenant
app.post("/auth/verify-email-code", async (req, res) => {
  try {
    const { email, code } = req.body || {};
    const cleanEmail = String(email || "").trim().toLowerCase();
    const rec = emailOtpStore[cleanEmail];

    if (!isEmail(cleanEmail)) 
      return res.status(400).json({ ok: false, message: "אימייל לא תקין" });
    
    if (!rec) 
      return res.status(400).json({ ok: false, message: "לא נשלח קוד" });
    
    if (rec.expires < Date.now()) {
      delete emailOtpStore[cleanEmail];
      return res.status(400).json({ ok: false, message: "קוד פג תוקף" });
    }
    
    if (rec.code !== String(code)) 
      return res.status(400).json({ ok: false, message: "קוד שגוי" });

    // ✅ בודקים אם המשתמש קיים
    let user = await User.findOne({ email: cleanEmail });
    
    if (!user) {
      // 🔹 שלב 1: יוצרים User תחילה (ללא Tenant)
      user = await User.create({
        username: rec.name,
        email: cleanEmail,
        name: rec.name,
        role: "user",
        TenantName: rec.tenantName,
        memberships: []  // ריק בינתיים
      });

      // 🔹 שלב 2: יוצרים Tenant עם ה-owner שיצרנו
      const newTenant = await Tenant.create({
        name: rec.tenantName,
        owner: user._id  // ✅ עכשיו יש לנו ID של User אמיתי
      });

      // 🔹 שלב 3: מעדכנים את ה-User עם ה-Tenant
      user.TenantID = newTenant._id;
      user.memberships = [{
        tenant: newTenant._id,
        role: 'owner'
      }];
      await user.save();
    }

    // ✅ יוצרים JWT token
    const payload = { id: user._id.toString() };
    const token = jwt.sign(payload, SECRET, { expiresIn: "7d" });
    
    res.cookie("token", token, {
      sameSite: "lax",
      secure: isProd,
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7
    });

    delete emailOtpStore[cleanEmail];

res.json({
  ok: true,
  message: "מחובר!",
  redirect: "/",  // 🆕 הוספה
  user: {
    id: user._id,
    username: user.username || rec.name || cleanEmail.split("@")[0],
    email: user.email,
    role: user.role,
    tenantName: user.TenantName,
    tenantId: user.TenantID
  }
});
  } catch (err) {
    console.error("verify-email-code error:", err);
    res.status(500).json({ ok: false, message: "שגיאה באימות" });
  }
});

// הרשמה ידנית (ללא סיסמה)
app.post("/register", async (req, res) => {
  try {
    const { username, email, name } = req.body || {};
    if (!username || !email || !name) {
      return res.status(400).json({ ok: false, message: "חסר נתונים" });
    }

    const cleanUsername = username.trim().toLowerCase();
    const cleanEmail    = email.trim().toLowerCase();

    const existing = await User.findOne({ $or: [{ username: cleanUsername }, { email: cleanEmail }] });
    if (existing) {
      return res.status(400).json({ ok: false, message: "שם משתמש או אימייל כבר בשימוש" });
    }

    const user = await User.create({
      username: cleanUsername,
      email: cleanEmail,
      name: name.trim(),
      role: "user"
    });

    res.json({ ok: true, message: "נרשמת בהצלחה", user: { id: user._id, username: user.username, email: user.email } });
  } catch (err) {
    console.error("register error:", err);
    res.status(500).json({ ok: false, message: "שגיאה ברישום" });
  }
});

// מי מחובר? (ע"פ cookie JWT)
app.get("/me", authenticateUser, (req,res) => {
  const user = req.user;
  res.json({
    ok: true,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      platformRole: user.platformRole || "user"
    },
    isPlatformAdmin: isPlatformAdmin(user)
  });
});
console.log("[ADMIN EMAILS]", process.env.PLATFORM_ADMIN_EMAILS);
// תאימות לאחור אם יש קוד פרונט שמחפש cookie בשם "user"
app.get("/user", (req, res) => {
  if (req.cookies && req.cookies.user) {
    try {
      const user = JSON.parse(req.cookies.user);
      return res.json({ ok: true, user });
    } catch {
      return res.json({ ok: false });
    }
  }
  res.json({ ok: false });
});

// server.js (או קובץ הראוטים שלך)
app.put("/api/user/update", authenticateUser, async (req, res) => {
  try {
    const { name } = req.body || {};
    const cleanName = String(name || "").trim();

    if (!cleanName) {
      return res.status(400).json({ ok: false, message: "יש להזין שם מלא" });
    }
    if (cleanName.length > 80) {
      return res.status(400).json({ ok: false, message: "שם ארוך מדי" });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ ok: false, message: "משתמש לא נמצא" });
    }

    user.name = cleanName;
    await user.save();

    return res.json({
      ok: true,
      message: "הפרופיל עודכן בהצלחה",
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (err) {
    console.error("user/update error:", err);
    return res.status(500).json({ ok: false, message: "שגיאה בעדכון הפרופיל" });
  }
});

// Middleware לבדיקת authentication


// Route לקבלת פרטי המשתמש והעסק
app.get("/api/tenant/info", authenticateUser, async (req, res) => {
  try {
    const user = req.user;
    
    // מוצאים את הטנאנט
    const tenant = await Tenant.findById(user.TenantID).lean();
      const featureState = Object.fromEntries(
    Object.keys(FEATURE_CATALOG).map(k => [k, !!(tenant.features && tenant.features.get && tenant.features.get(k))])
  );
    if (!tenant) {
      return res.status(404).json({ 
        ok: false, 
        message: "עסק לא נמצא" 
      });
    }

    // מוצאים את כל חברי הצוות של העסק
    const teamMembers = await User.find({ 
      TenantID: tenant._id 
    }).select('name email role memberships').lean();

    // מוצאים מי הבעלים
    const owner = teamMembers.find(m => 
      m.memberships?.some(mem => 
        mem.tenant.toString() === tenant._id.toString() && 
        mem.role === 'owner'
      )
    );

    res.json({
      ok: true,
      tenant: {
        id: tenant._id,
        name: tenant.name,
        createdAt: tenant.createdAt,
        settings: tenant.settings,
features: tenant.features || {}
      },
      currentUser: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.memberships?.find(m => 
          m.tenant.toString() === tenant._id.toString()
        )?.role || 'staff'
      },
      owner: owner ? {
        name: owner.name,
        email: owner.email
      } : null,
      teamMembers: teamMembers.map(m => ({
        id: m._id,
        name: m.name,
        email: m.email,
        role: m.memberships?.find(mem => 
          mem.tenant.toString() === tenant._id.toString()
        )?.role || 'staff'
      }))
    });
  } catch (err) {
    console.error("tenant/info error:", err);
    res.status(500).json({ 
      ok: false, 
      message: "שגיאה בטעינת נתוני העסק" 
    });
  }
});

// Route לעדכון פרטי עסק (רק לבעלים/מנהלים)
app.put("/api/tenant/update", authenticateUser, async (req, res) => {
  try {
    const user = req.user;
    const { name, settings } = req.body;

    // בדיקה שהמשתמש הוא owner או admin
    const membership = user.memberships?.find(m => 
      m.tenant.toString() === user.TenantID.toString()
    );

    if (!membership || !['owner', 'admin'].includes(membership.role)) {
      return res.status(403).json({ 
        ok: false, 
        message: "אין הרשאה לעדכן פרטי העסק" 
      });
    }

    const tenant = await Tenant.findById(user.TenantID);
    if (!tenant) {
      return res.status(404).json({ 
        ok: false, 
        message: "עסק לא נמצא" 
      });
    }

    // עדכון פרטים
    if (name) tenant.name = name.trim();
    if (settings) {
      tenant.settings = { ...tenant.settings, ...settings };
    }

    await tenant.save();

    res.json({ 
      ok: true, 
      message: "העסק עודכן בהצלחה",
      tenant: {
        id: tenant._id,
        name: tenant.name,
        settings: tenant.settings
      }
    });
  } catch (err) {
    console.error("tenant/update error:", err);
    res.status(500).json({ 
      ok: false, 
      message: "שגיאה בעדכון העסק" 
    });
  }
});


// Logout (מנקה קוקים)
app.post("/logout", (req, res) => {
  res.clearCookie("token", { sameSite: "lax", secure: isProd, httpOnly: true });
  res.clearCookie("user", { sameSite: "lax" });
  res.json({ ok: true, message: "התנתקת בהצלחה" });
});
app.get("/logout", (req, res) => {
  const isProd = process.env.NODE_ENV === 'production';
  // חשוב: אותן אפשרויות כמו בזמן ה-set כדי שיימחק בטוח
  res.clearCookie("token", { sameSite: "lax", secure: isProd, httpOnly: true });
  res.clearCookie("user",  { sameSite: "lax" });
  return res.redirect("/login");
});
// ===== Error handler =====
app.use((err, req, res, next) => {
  console.error("🔥 Express Error:", err);
  res.status(500).json({ ok: false, message: "Server error", error: err.message });
});

// ===== Start / Export (Vercel) =====
if (process.env.VERCEL) {
  module.exports = app;
} else {
  app.listen(PORT, () => console.log(`🚀 Auth server listening on :${PORT}`));
}
